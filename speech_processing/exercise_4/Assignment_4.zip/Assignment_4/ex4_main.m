% ELEC-E5500 Speech Processing -- Autumn 2018 Matlab Exercise 4:
% PSOLA

clear;
close all;

%% Read and window the vowel segment aa.wav:
% 0.1. Read the audio file aa.wav and sampling rate
[data_vowel, Fs] = ...;

% 0.2. Make sure the sampling rate is 16kHz
if Fs ~=    
    data_vowel = ... ; % resampling
    Fs = ...;   % re-assign sampling rate
end

% 0.3. Split the data sequence in to windows. Use ex1_windowing.m
frame_length = round(0.05*Fs); % 25ms in samples
hop_size = round(0.0125*Fs); % 12.5ms in samples (50% overlap)
window_types = {'rect','hann','cosine','hamming'};
win_type = ;
frame_matrix_vowel = ex1_windowing_solution(data_vowel, frame_length, hop_size, window_types{win_type}); % Implement this!

%% Section 1: Modify the pitch of the vowel 'aa'
% Use solution from exercise 2 to estimate the fundamental frequency. You
% can use either the autocorrelation or the cepstral method 

% Define minimum and maximum values for the F0 search range, and the
% threshold value for Voiced/Unvoiced decision
f0_max = ...;
f0_min = ...;
vuv_threshold_ac = ...;

% Loop through frame_matrix_vowel that calls the function ex2_fundf_autocorr to obtain
% the F0 estimates for each frame
f0_vec_original_vowel = zeros(1,size(frame_matrix_vowel,2)); % Allocate f0 vector for autocorrelation method
ac_peak_vec_vowel = zeros(1,size(frame_matrix_vowel,2));
for iFrame = 1:size(frame_matrix_vowel,2)
    [f0_vec_original_vowel(iFrame), ac_peak_vec_vowel(iFrame)] = ex2_fundf_autocorr_solution(frame_matrix_vowel(:,iFrame),..);
end

% 1.1 Modify the pitch of the underlying data (vowel) by applying PSOLA
% Initialize a constant target pitch frequency (greater than 50 Hz)
f0_vec_target_vowel = ...;
% Apply PSOLA
vowel_pitch_modified = ex4_psola(data_vowel, Fs, hop_size, f0_vec_original_vowel, f0_vec_target_vowel);

% Plotting and visualization
% 1.2 Plot the original signal and the pitch modified signal and label the
% axes and the title with appropriate strings
figure;
% Original vowel signal
subplot(2, 2, 1);


% Pitch modified vowel signal
subplot(2, 2, 2); 

% Spectrogram of vowel signal
subplot(2, 2, 3);


% 3.2 Spectrogram of pitch modified vowel
subplot(2, 2, 4);


%% Section 2: Modify the pitch of the sentence in SX83.WAV
% 0.1. Read the audio file SX83.WAV and sampling rate
[data_sentence, Fs] = ...;

% 0.2. Make sure the sampling rate is 16kHz
if Fs ~= ... 
    data_sentence = ...; % resample
    Fs = ...;  % Re-assign sampling rate
end

% 0.3. Split the data sequence in to windows. Use ex1_windowing.m
frame_matrix_sentence = ex1_windowing_solution(...); 

% Use solution from exercise 2 to estimate the fundamental frequency. You
% can use either the autocorrelation or the cepstral method

% Define minimum and maximum values for the F0 search range, and the
% threshold value for Voiced/Unvoiced decision
f0_max = ...;
f0_min = ...;
vuv_threshold_ac = ...;

% Write a loop through frame_matrix that calls the function ex2_fundf_autocorr to obtain
% the F0 estimates for each frame
f0_vec_original_sentence = zeros(1,size(frame_matrix_sentence,2)); % Allocate f0 vector for autocorrelation method
ac_peak_vec_sentence = zeros(1,size(frame_matrix_sentence,2));
for iFrame = 1:size(frame_matrix_sentence,2)
    [f0_vec_original_sentence(iFrame), ac_peak_vec_sentence(iFrame)] = ex2_fundf_autocorr_solution(frame_matrix_sentence(:,iFrame),..);
end

% 2.1 Modify the pitch of the underlying data (sentence) by applying PSOLA
% Initialize a constant target pitch
f0_vec_target_sentence_constant = ...;
    
% Apply PSOLA to modify the pitch to the target constant pitch
sentence_pitch_modified_const = ex4_psola(data_sentence, Fs, hop_size, f0_vec_original, f0_vec_target_sentence_constant);

% 2.2 Modify the pitch of the underlying data (sentence) by applying PSOLA
% Initialize a variable target pitch vector
f0_vec_target_sentence_variable = ...;

% Apply PSOLA to modify the pitch to the target constant pitch
sentence_pitch_modified_var = ex4_psola_solution(data_sentence, Fs, hop_size, f0_vec_original_sentence, f0_vec_target_sentence_variable);

% Plotting and visualization
% 2.3.1 Plot the original signal and the pitch modified signal and label the
% axes and the title with appropriate strings
figure;
% plot original sentence
subplot(2, 3, 1);


% Plot the Constant Pitch modified signal-sentence_pitch_modified_const
subplot(2, 3, 2); 


% Plot the Variable Pitch modified signal-sentence_pitch_modified_var
subplot(2, 3, 3); 

% 2.3.2 Compute and plot the spectrogram

% spectrogram of the original sentence
subplot(2, 3, 4);


% spectrogram of the constant pitch modified sentence-sentence_pitch_modified_const
subplot(2, 3, 5);


% spectrogram of the variable pitch modified sentence-sentence_pitch_modified_var
subplot(2, 3, 6);


%% Experiment with different target frequencies
% a) Difference between a constant and varying pitch modified signal?
% b) Can you spot this difference from the signal spectrograms? If yes,
% how?
% c) What changes do you observe in the signal plots (time domain and
% spectrogram), when you increase and decrease the pitch?
% d) Can you thing of any applications of this PSOLA implementation for
% pitch modification?
