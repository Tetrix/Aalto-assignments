function [ zcr ] = exc3_zcr( frame )
%EXC3_ZCR ZERO-CROSSING RATE COMPUTATION
%   Count the number of times that a signal crosses the zero-line
%   Inputs: frame : the input signal frame
%
%   Outputs: zcr : The zero-crossing rate of a zero-mean frame. (I.e.
%   remember to remove the mean from frame!)


end

